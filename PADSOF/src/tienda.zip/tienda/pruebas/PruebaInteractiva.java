package pruebas;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Scanner;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Main de prueba interactivo por terminal.
 *
 * Está hecho para que puedas probar el flujo típico de un cliente: - login /
 * registro - ver catálogo - ver recomendados - añadir varias unidades al
 * carrito - ver carrito - ver ofertas - ver notificaciones - ver estado de
 * pedidos - finalizar compra
 *
 * IMPORTANTE: Como en los archivos accesibles no está el contenido real de tus
 * clases, este main funciona de forma autónoma con clases internas de apoyo. Si
 * luego me pasas tus .java o .class accesibles, se puede conectar a Cliente,
 * Tienda, Notificacion, Recomendador, etc.
 */
public class PruebaInteractiva {

	private static final Scanner SC = new Scanner(System.in);
	private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

	private final Map<String, Usuario> usuarios = new LinkedHashMap<>();
	private final Map<Integer, Producto> catalogo = new LinkedHashMap<>();
	private final List<Pedido> pedidosGlobales = new ArrayList<>();

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		Locale.setDefault(new Locale("es", "ES"));
		new PruebaInteractiva().iniciar();
	}

	public void iniciar() {
		cargarDatosDemo();
		mostrarBanner();

		boolean salir = false;
		while (!salir) {
			System.out.println("\n=========== MENÚ PRINCIPAL ===========");
			System.out.println("1. Iniciar sesión");
			System.out.println("2. Registrarse");
			System.out.println("3. Entrar como invitado");
			System.out.println("0. Salir");

			switch (leerEntero("Elige una opción: ", 0, 3)) {
			case 1 -> login();
			case 2 -> registro();
			case 3 -> menuCliente(Usuario.invitado());
			case 0 -> {
				salir = true;
				System.out.println("\nGracias por probar la tienda.");
			}
			}
		}
	}

	private void mostrarBanner() {
		System.out.println("============================================");
		System.out.println("    DEMO INTERACTIVA - TIENDA POR TERMINAL  ");
		System.out.println("============================================");
		System.out.println("Usuarios demo:");
		System.out.println("- ana / 1234");
		System.out.println("- carlos / 1234");
	}

	private void login() {
		System.out.println("\n--- INICIO DE SESIÓN ---");
		String usuario = leerTexto("Usuario: ");
		String password = leerTexto("Contraseña: ");

		Usuario u = usuarios.get(usuario.toLowerCase());
		if (u == null || !u.password.equals(password)) {
			System.out.println("Credenciales incorrectas.");
			return;
		}

		System.out.println("Bienvenido/a, " + u.nombre + ".");
		menuCliente(u);
	}

	private void registro() {
		System.out.println("\n--- REGISTRO ---");
		String username;
		while (true) {
			username = leerTexto("Elige nombre de usuario: ").toLowerCase();
			if (!usuarios.containsKey(username)) {
				break;
			}
			System.out.println("Ese usuario ya existe.");
		}

		String nombre = leerTexto("Nombre visible: ");
		String password = leerTexto("Contraseña: ");

		Usuario nuevo = new Usuario(username, nombre, password, false);
		nuevo.notificaciones.add("Tu cuenta se ha creado correctamente.");
		nuevo.notificaciones.add("Completa tu primera compra para desbloquear recomendaciones personalizadas.");
		usuarios.put(username, nuevo);

		System.out.println("Usuario registrado con éxito.");
		menuCliente(nuevo);
	}

	private void menuCliente(Usuario usuario) {
		boolean cerrarSesion = false;

		while (!cerrarSesion) {
			System.out.println("\n============= ZONA CLIENTE =============");
			System.out.println("Sesión: " + usuario.nombre + (usuario.invitado ? " (invitado)" : ""));
			System.out.println("1. Ver catálogo");
			System.out.println("2. Ver productos recomendados");
			System.out.println("3. Añadir producto al carrito");
			System.out.println("4. Ver carrito");
			System.out.println("5. Ver ofertas");
			System.out.println("6. Ver notificaciones");
			System.out.println("7. Ver estado de pedidos");
			System.out.println("8. Finalizar compra");
			System.out.println("9. Buscar producto por nombre");
			System.out.println("10. Quitar producto del carrito");
			System.out.println("11. Vaciar carrito");
			System.out.println("0. Cerrar sesión");

			switch (leerEntero("Selecciona una opción: ", 0, 11)) {
			case 1 -> verCatalogo();
			case 2 -> verRecomendados(usuario);
			case 3 -> anadirAlCarrito(usuario);
			case 4 -> verCarrito(usuario);
			case 5 -> verOfertas();
			case 6 -> verNotificaciones(usuario);
			case 7 -> verPedidos(usuario);
			case 8 -> finalizarCompra(usuario);
			case 9 -> buscarProducto();
			case 10 -> quitarDelCarrito(usuario);
			case 11 -> vaciarCarrito(usuario);
			case 0 -> cerrarSesion = true;
			}
		}
	}

	private void verCatalogo() {
		System.out.println("\n--- CATÁLOGO ---");
		catalogo.values().stream().sorted(Comparator.comparing(p -> p.categoria)).forEach(this::imprimirProducto);
	}

	private void verRecomendados(Usuario usuario) {
		System.out.println("\n--- RECOMENDACIONES ---");

		List<Producto> recomendados = catalogo.values().stream().filter(p -> p.stock > 0)
				.sorted((a, b) -> puntuacionRecomendacion(usuario, b) - puntuacionRecomendacion(usuario, a)).limit(5)
				.collect(Collectors.toList());

		if (recomendados.isEmpty()) {
			System.out.println("No hay productos recomendados ahora mismo.");
			return;
		}

		for (Producto p : recomendados) {
			int score = puntuacionRecomendacion(usuario, p);
			System.out.println("[score=" + score + "]");
			imprimirProducto(p);
		}
	}

	private int puntuacionRecomendacion(Usuario usuario, Producto p) {
		int score = 0;
		if (usuario.categoriasFavoritas.contains(p.categoria)) {
			score += 50;
		}
		if (p.tieneDescuento()) {
			score += 20;
		}
		if (usuario.historialCategorias.containsKey(p.categoria)) {
			score += usuario.historialCategorias.get(p.categoria) * 10;
		}
		score += Math.min(p.stock, 20);
		return score;
	}

	private void anadirAlCarrito(Usuario usuario) {
		System.out.println("\n--- AÑADIR AL CARRITO ---");
		verCatalogo();

		int id = leerEntero("Introduce el ID del producto: ");
		Producto p = catalogo.get(id);
		if (p == null) {
			System.out.println("No existe un producto con ese ID.");
			return;
		}

		if (p.stock <= 0) {
			System.out.println("Ese producto no tiene stock disponible.");
			return;
		}

		int cantidad = leerEntero("¿Cuántas unidades quieres añadir?: ", 1, p.stock);
		usuario.carrito.merge(p, cantidad, Integer::sum);
		System.out.println("Añadidas " + cantidad + " unidad(es) de '" + p.nombre + "' al carrito.");
	}

	private void verCarrito(Usuario usuario) {
		System.out.println("\n--- CARRITO ---");
		if (usuario.carrito.isEmpty()) {
			System.out.println("El carrito está vacío.");
			return;
		}

		double total = 0;
		for (Map.Entry<Producto, Integer> entry : usuario.carrito.entrySet()) {
			Producto p = entry.getKey();
			int cantidad = entry.getValue();
			double subtotal = p.precioFinal() * cantidad;
			total += subtotal;
			System.out.printf("- [%d] %s | uds: %d | %.2f €/ud | subtotal: %.2f €%n", p.id, p.nombre, cantidad,
					p.precioFinal(), subtotal);
		}
		System.out.printf("TOTAL DEL CARRITO: %.2f €%n", total);
	}

	private void verOfertas() {
		System.out.println("\n--- OFERTAS ACTIVAS ---");
		List<Producto> ofertas = catalogo.values().stream().filter(Producto::tieneDescuento)
				.sorted(Comparator.comparingDouble(Producto::porcentajeDescuento).reversed())
				.collect(Collectors.toList());

		if (ofertas.isEmpty()) {
			System.out.println("No hay ofertas activas en este momento.");
			return;
		}

		for (Producto p : ofertas) {
			System.out.printf("ID %d | %s | antes %.2f € -> ahora %.2f € (%.0f%% dto.)%n", p.id, p.nombre, p.precio,
					p.precioOferta, p.porcentajeDescuento());
		}
	}

	private void verNotificaciones(Usuario usuario) {
		System.out.println("\n--- NOTIFICACIONES ---");
		if (usuario.invitado) {
			System.out.println("Como invitado no tienes notificaciones personales.");
			return;
		}

		if (usuario.notificaciones.isEmpty()) {
			System.out.println("No tienes notificaciones nuevas.");
			return;
		}

		for (int i = 0; i < usuario.notificaciones.size(); i++) {
			System.out.println((i + 1) + ". " + usuario.notificaciones.get(i));
		}
	}

	private void verPedidos(Usuario usuario) {
		System.out.println("\n--- ESTADO DE PEDIDOS ---");
		if (usuario.invitado) {
			System.out.println("Como invitado no tienes historial de pedidos persistente.");
			return;
		}

		if (usuario.pedidos.isEmpty()) {
			System.out.println("Aún no has realizado pedidos.");
			return;
		}

		for (Pedido pedido : usuario.pedidos) {
			System.out.println("Pedido " + pedido.codigo + " | " + pedido.fecha.format(FMT));
			System.out.println("Estado actual: " + pedido.estadoActual());
			for (String estado : pedido.estados) {
				System.out.println("   - " + estado);
			}
			System.out.printf("Total: %.2f €%n", pedido.total);
			System.out.println();
		}
	}

	private void finalizarCompra(Usuario usuario) {
		System.out.println("\n--- FINALIZAR COMPRA ---");
		if (usuario.carrito.isEmpty()) {
			System.out.println("No puedes finalizar una compra con el carrito vacío.");
			return;
		}

		if (usuario.invitado) {
			System.out.println("Como invitado puedes simular la compra, pero no se guardará historial.");
		}

		// Validar stock antes de comprar
		for (Map.Entry<Producto, Integer> entry : usuario.carrito.entrySet()) {
			Producto p = entry.getKey();
			int cantidad = entry.getValue();
			if (cantidad > p.stock) {
				System.out.println("No hay stock suficiente para: " + p.nombre + ". Disponible: " + p.stock);
				return;
			}
		}

		double total = 0;
		for (Map.Entry<Producto, Integer> entry : usuario.carrito.entrySet()) {
			Producto p = entry.getKey();
			int cantidad = entry.getValue();
			p.stock -= cantidad;
			total += p.precioFinal() * cantidad;
			usuario.historialCategorias.merge(p.categoria, cantidad, Integer::sum);
		}

		Pedido pedido = new Pedido(total);
		pedidosGlobales.add(pedido);
		if (!usuario.invitado) {
			usuario.pedidos.add(0, pedido);
			usuario.notificaciones.add(0, "Tu pedido " + pedido.codigo + " se ha registrado correctamente.");
			usuario.notificaciones.add(1, "Seguimiento pedido " + pedido.codigo + ": " + pedido.estadoActual());
		}

		usuario.carrito.clear();
		System.out.printf("Compra realizada con éxito. Total pagado: %.2f €%n", total);
		System.out.println("Código de pedido: " + pedido.codigo);
	}

	private void buscarProducto() {
		System.out.println("\n--- BUSCAR PRODUCTO ---");
		String texto = leerTexto("Introduce texto a buscar: ").toLowerCase();

		List<Producto> resultados = catalogo
				.values().stream().filter(p -> p.nombre.toLowerCase().contains(texto)
						|| p.categoria.toLowerCase().contains(texto) || p.descripcion.toLowerCase().contains(texto))
				.collect(Collectors.toList());

		if (resultados.isEmpty()) {
			System.out.println("No se han encontrado productos con ese criterio.");
			return;
		}

		resultados.forEach(this::imprimirProducto);
	}

	private void quitarDelCarrito(Usuario usuario) {
		System.out.println("\n--- QUITAR DEL CARRITO ---");
		if (usuario.carrito.isEmpty()) {
			System.out.println("El carrito ya está vacío.");
			return;
		}

		verCarrito(usuario);
		int id = leerEntero("ID del producto a quitar: ");

		Producto producto = null;
		for (Producto p : usuario.carrito.keySet()) {
			if (p.id == id) {
				producto = p;
				break;
			}
		}

		if (producto == null) {
			System.out.println("Ese producto no está en el carrito.");
			return;
		}

		int max = usuario.carrito.get(producto);
		int cantidad = leerEntero("¿Cuántas unidades quieres quitar?: ", 1, max);

		int restante = max - cantidad;
		if (restante == 0) {
			usuario.carrito.remove(producto);
		} else {
			usuario.carrito.put(producto, restante);
		}

		System.out.println("Carrito actualizado.");
	}

	private void vaciarCarrito(Usuario usuario) {
		System.out.println("\n--- VACIAR CARRITO ---");
		if (usuario.carrito.isEmpty()) {
			System.out.println("El carrito ya está vacío.");
			return;
		}

		String confirmar = leerTexto("Escribe SI para confirmar: ");
		if ("SI".equalsIgnoreCase(confirmar)) {
			usuario.carrito.clear();
			System.out.println("Carrito vaciado.");
		} else {
			System.out.println("Operación cancelada.");
		}
	}

	private void imprimirProducto(Producto p) {
		String precio = p.tieneDescuento() ? String.format("%.2f € (antes %.2f €)", p.precioOferta, p.precio)
				: String.format("%.2f €", p.precio);

		System.out.printf("ID %d | %s | %s | stock: %d | %s%n", p.id, p.nombre, p.categoria, p.stock, precio);
		System.out.println("   " + p.descripcion);
	}

	private int leerEntero(String mensaje) {
		while (true) {
			System.out.print(mensaje);
			String linea = SC.nextLine().trim();
			try {
				return Integer.parseInt(linea);
			} catch (NumberFormatException e) {
				System.out.println("Introduce un número válido.");
			}
		}
	}

	private int leerEntero(String mensaje, int min, int max) {
		while (true) {
			int valor = leerEntero(mensaje);
			if (valor >= min && valor <= max) {
				return valor;
			}
			System.out.println("El número debe estar entre " + min + " y " + max + ".");
		}
	}

	private String leerTexto(String mensaje) {
		while (true) {
			System.out.print(mensaje);
			String texto = SC.nextLine().trim();
			if (!texto.isEmpty()) {
				return texto;
			}
			System.out.println("No puede estar vacío.");
		}
	}

	private void cargarDatosDemo() {
		catalogo.put(1, new Producto(1, "Portátil Pro 14", "Tecnología", 1299.99, 1149.99, 6,
				"Portátil ligero de 14 pulgadas con 16 GB RAM."));
		catalogo.put(2, new Producto(2, "Auriculares NoiseFree", "Tecnología", 199.99, 149.99, 15,
				"Auriculares inalámbricos con cancelación de ruido."));
		catalogo.put(3, new Producto(3, "Cafetera Barista Mini", "Hogar", 89.90, null, 9,
				"Cafetera compacta para espresso y cappuccino."));
		catalogo.put(4, new Producto(4, "Zapatillas Runner X", "Deporte", 120.00, 84.90, 20,
				"Zapatillas ligeras para running urbano."));
		catalogo.put(5, new Producto(5, "Mochila Travel 30L", "Viaje", 69.95, null, 12,
				"Mochila resistente al agua con compartimento para portátil."));
		catalogo.put(6, new Producto(6, "Silla ergonómica Flex", "Oficina", 249.99, 219.99, 4,
				"Silla de oficina con soporte lumbar ajustable."));
		catalogo.put(7, new Producto(7, "Pack Botellas Fitness", "Deporte", 24.50, 17.99, 30,
				"Set de 3 botellas reutilizables para gimnasio."));
		catalogo.put(8, new Producto(8, "Lámpara Smart Home", "Hogar", 39.99, 29.99, 25,
				"Lámpara LED regulable compatible con asistentes de voz."));

		Usuario ana = new Usuario("ana", "Ana", "1234", false);
		ana.categoriasFavoritas.add("Tecnología");
		ana.categoriasFavoritas.add("Hogar");
		ana.notificaciones.add("Tienes un cupón del 10% para productos de Hogar.");
		ana.notificaciones.add("Nuevo seguimiento disponible para tu último pedido.");
		Pedido p1 = new Pedido(149.99);
		p1.estados.clear();
		p1.estados.add("Pedido registrado");
		p1.estados.add("En preparación");
		p1.estados.add("En reparto");
		ana.pedidos.add(p1);
		ana.historialCategorias.put("Tecnología", 3);
		usuarios.put(ana.username, ana);

		Usuario carlos = new Usuario("carlos", "Carlos", "1234", false);
		carlos.categoriasFavoritas.add("Deporte");
		carlos.categoriasFavoritas.add("Viaje");
		carlos.notificaciones.add("Tus zapatillas favoritas tienen ahora un 29% de descuento.");
		carlos.historialCategorias.put("Deporte", 4);
		usuarios.put(carlos.username, carlos);
	}

	// ===================== CLASES DE APOYO =====================

	private static class Usuario {
		String username;
		String nombre;
		String password;
		boolean invitado;
		Map<Producto, Integer> carrito = new LinkedHashMap<>();
		List<String> notificaciones = new ArrayList<>();
		List<Pedido> pedidos = new ArrayList<>();
		List<String> categoriasFavoritas = new ArrayList<>();
		Map<String, Integer> historialCategorias = new LinkedHashMap<>();

		Usuario(String username, String nombre, String password, boolean invitado) {
			this.username = username;
			this.nombre = nombre;
			this.password = password;
			this.invitado = invitado;
		}

		static Usuario invitado() {
			return new Usuario("invitado", "Invitado", "", true);
		}
	}

	private static class Producto {
		int id;
		String nombre;
		String categoria;
		double precio;
		Double precioOferta;
		int stock;
		String descripcion;

		Producto(int id, String nombre, String categoria, double precio, Double precioOferta, int stock,
				String descripcion) {
			this.id = id;
			this.nombre = nombre;
			this.categoria = categoria;
			this.precio = precio;
			this.precioOferta = precioOferta;
			this.stock = stock;
			this.descripcion = descripcion;
		}

		boolean tieneDescuento() {
			return precioOferta != null && precioOferta < precio;
		}

		double precioFinal() {
			return tieneDescuento() ? precioOferta : precio;
		}

		double porcentajeDescuento() {
			if (!tieneDescuento()) {
				return 0;
			}
			return ((precio - precioOferta) / precio) * 100;
		}
	}

	private static class Pedido {
		String codigo;
		LocalDateTime fecha;
		double total;
		List<String> estados = new ArrayList<>();

		Pedido(double total) {
			this.codigo = UUID.randomUUID().toString().substring(0, 8).toUpperCase();
			this.fecha = LocalDateTime.now();
			this.total = total;
			this.estados.add("Pedido registrado");
			this.estados.add("Pago confirmado");
			this.estados.add("Preparando envío");
		}

		String estadoActual() {
			return estados.get(estados.size() - 1);
		}
	}
}
