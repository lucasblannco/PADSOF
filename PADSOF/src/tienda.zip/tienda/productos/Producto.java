package productos;

public abstract class Producto {
	protected String id;
	protected String nombre;
	protected String descripcion;
	protected String imagenRuta;

	public Producto(String nombre, String descripcion, String imagenRuta) {
		this.id = "0";
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.imagenRuta = imagenRuta;
	}

	public String getId() {
		return this.id;
	}

	public String getNombre() {
		return this.nombre;
	}

	@Override
	public String toString() {
		return "[" + this.id + "] " + this.getNombre() + " | Imagen: " + this.getImagenRuta() + " |";
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getImagenRuta() {
		return imagenRuta;
	}

	public void setImagenRuta(String imagenRuta) {
		this.imagenRuta = imagenRuta;
	}

}
