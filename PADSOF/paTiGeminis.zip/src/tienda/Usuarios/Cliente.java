package tienda.Usuarios;

import java.util.List;

import tienda.Intercambios.Oferta;
import tienda.Productos.*;
import tienda.Ventas.*;
import java.util.ArrayList;

public class Cliente extends UsuarioRegistrado {
    //private double saldoPuntos;
    private List<Pedido> historialPedidos;
    private Carrito carritoActual;
    private List<ProductoSegundaMano> carteraIntercambio;
    private List<Oferta> ofertasPendientes; 
    private List<Oferta> historialIntercambios;
    private List<Reseña> reseñas;
    protected List<Notificacion> notificaciones;

    public Cliente() {
        super();
        this.historialPedidos = new ArrayList<>();
        this.carteraIntercambio = new ArrayList<>();
        this.ofertasPendientes = new ArrayList<>();
        this.reseñas = new ArrayList<>();
    }

    @Override
    public void mostrarPanelPrincipal() {
    }

    public void hacerOferta(Cliente destino, List<ProductoSegundaMano> ofertados,List<ProductoSegundaMano> solicitados) {
    	
    }
    
    public void confirmarIntercambio(Oferta oferta) {
        
        oferta.aceptarYEjecutar(); 
        Tienda.getInstancia().finalizarIntercambio(oferta);

        this.historialIntercambios.add(oferta);
        oferta.getOrigen().getHistorialIntercambios().add(oferta);
        this.ofertasPendientes.remove(oferta);
     
        oferta.getOrigen().recibirNotificacion("¡Intercambio realizado! ID: " + oferta.getId());
    }
    
    public void procesarRechazo(Oferta oferta) {
        // 1. Liberar productos        oferta.rechazar();
        this.getOfertasPendientes().remove(oferta);
        oferta.getOrigen().recibirNotificacion("Tu oferta con ID " Tienda.getInstancia().finalizarIntercambio(oferta);+ oferta.getId() + " ha sido RECHAZADA.");
    }
    
    public void escribirReseña(ProductoVenta p, int pts, String texto) {
        Reseña nueva = new Reseña(this, p, pts, texto);
        this.reseñas.add(nueva); // El cliente la guarda
        p.getReseñas().add(nueva);  // El producto también la recibe
    }

    
    
   
    	public void addProducto2Mano (ProductoSegundaMano p) {
    		this.carteraIntercambio.add(p);
    	}
    	
    
        
     // --- GETTERS ---
       

        public List<Pedido> getHistorialPedidos() {
            return historialPedidos;
        }

        public Carrito getCarritoActual() {
            return carritoActual;
        }

        public List<ProductoSegundaMano> getCarteraIntercambio() {
            return carteraIntercambio;
        }

        public List<Oferta> getOfertasPendientes() {
            return ofertasPendientes;
        }

        public List<Oferta> getHistorialIntercambios() {
            return historialIntercambios;
        }

        public List<Reseña> getReseñas() {
            return reseñas;
        }

        public List<Notificacion> getNotificaciones() {
            return notificaciones;
        }

        // --- SETTERS ---
        

        public void setCarritoActual(Carrito carritoActual) {
            this.carritoActual = carritoActual;
        }
        
        
     // 1. Creamos el nuevo objeto Cliente
        // --- MÉTODOS DE APOYO (Necesarios para que el código compile) ---

        //REVISAR
        public void recibirNotificacion(String mensaje) {
            if (this.notificaciones == null) {
                this.notificaciones = new ArrayList<>();
            }
            // Si aún no has creado la clase Notificacion, puedes pasarle un String 
            // o crear el objeto aquí mismo si ya la tienes.
            this.notificaciones.add(new Notificacion(mensaje));
            System.out.println("[Notificación Cliente]: " + mensaje);
        }
}